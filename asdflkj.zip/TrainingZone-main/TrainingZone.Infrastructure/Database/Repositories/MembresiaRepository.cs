﻿using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class MembresiaRepository : Repository<Membresia>, IMembresiaRepository
{
    public MembresiaRepository(ApplicationDbContext context)
        : base(context)
    {
    }
}
