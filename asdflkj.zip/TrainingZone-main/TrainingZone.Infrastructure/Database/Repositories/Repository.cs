﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Common;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal abstract class Repository<TEntity>
    where TEntity : BaseEntity
{
    protected readonly ApplicationDbContext DbContext;

    protected Repository(ApplicationDbContext dbcontext)
    {
        DbContext = dbcontext;
    }

    public virtual Task<TEntity?> GetByIdAsync(long id, CancellationToken cancellationToken = default)
    {
        return DbContext.Set<TEntity>()
            .SingleOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public Task<List<TEntity>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return DbContext.Set<TEntity>()
            .ToListAsync(cancellationToken);
    }

    public void Add(TEntity entity)
    {
        DbContext.Set<TEntity>().Add(entity);
    }

    public void Update(TEntity entity)
    {
        DbContext.Set<TEntity>().Update(entity);
    }

    public void Remove(TEntity entity)
    {
        DbContext.Set<TEntity>().Remove(entity);
    }
}
