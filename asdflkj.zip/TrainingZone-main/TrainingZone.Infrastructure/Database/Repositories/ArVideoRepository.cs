﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class ArVideoRepository : Repository<ArVideo>, IArVideoRepository
{
    public ArVideoRepository(ApplicationDbContext dbcontext)
        : base(dbcontext)
    {
    }

    public override Task<ArVideo?> GetByIdAsync(long id, CancellationToken cancellationToken = default)
    {
        return DbContext.ArVideos
            .Include(x => x.EquipoFitness)
            .SingleOrDefaultAsync(x => x.Id == id, cancellationToken);
    }
}
