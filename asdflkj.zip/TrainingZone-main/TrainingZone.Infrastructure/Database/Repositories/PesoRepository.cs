﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class PesoRepository : Repository<Peso>, IPesoRepository
{
    public PesoRepository(ApplicationDbContext dbcontext)
        : base(dbcontext)
    {
    }

    public Task<List<Peso>> GetPesoByUserIdAsync(string userId, int intervalo=3, CancellationToken cancellationToken = default)
    {
        var monthInterval = DateTime.UtcNow.AddMonths(intervalo*(-1));

        return DbContext.Pesos
            .Where(p => p.AppUsuarioID == userId && p.FechaRegistro >= monthInterval)
            .OrderByDescending(p => p.FechaRegistro)
            .ToListAsync(cancellationToken);
    }
}
