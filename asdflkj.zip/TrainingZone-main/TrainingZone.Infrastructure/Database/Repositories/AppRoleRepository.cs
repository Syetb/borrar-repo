﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class AppRoleRepository : IAppRoleRepository
{
    private readonly ApplicationDbContext DbContext;

    public AppRoleRepository(ApplicationDbContext dbContext)
    {
        DbContext = dbContext;
    }

    public Task<AppRole?> GetByIdAsync(string id)
    {
        return DbContext.AppRoles
            .FirstOrDefaultAsync(x => x.Id == id);
    }
}
