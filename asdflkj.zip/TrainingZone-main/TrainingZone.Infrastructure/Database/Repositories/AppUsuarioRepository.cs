﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class AppUsuarioRepository : IAppUsuarioRepository
{
    private readonly ApplicationDbContext DbContext;

    public AppUsuarioRepository(ApplicationDbContext dbContext)
    {
        DbContext = dbContext;
    }

    public Task<List<AppUsuario>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return DbContext.AppUsuarios
            .Include(x => x.Pesos)
            .Include(x => x.Membresias)
            .ThenInclude(x => x.Pagos)
            .ToListAsync(cancellationToken);
    }

    public Task<AppUsuario?> GetByIdAsync(string userId, CancellationToken cancellationToken = default)
    {
        return DbContext.AppUsuarios
            .Include(x => x.Pesos)
            .Include(x => x.Membresias)
            .ThenInclude(x => x.Pagos)
            .FirstOrDefaultAsync(x => x.Id == userId, cancellationToken);
    }
}
