﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class CategoriaRepository : Repository<Categoria>, ICategoriaRepository
{
    public CategoriaRepository(ApplicationDbContext dbcontext)
        : base(dbcontext)
    {
    }

    public override Task<Categoria?> GetByIdAsync(long id, CancellationToken cancellationToken = default)
    {
        return DbContext.Categorias
            .Include(x => x.EquipoFitnesses)
            .SingleOrDefaultAsync(x => x.Id == id, cancellationToken);
    }
}
