﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class PagoRepository : Repository<Pago>, IPagoRepository
{
    public PagoRepository(ApplicationDbContext dbcontext)
        : base(dbcontext)
    {
    }
}
