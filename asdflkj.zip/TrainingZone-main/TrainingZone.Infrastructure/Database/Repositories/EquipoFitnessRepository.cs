﻿using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Infrastructure.Database.Repositories;

internal sealed class EquipoFitnessRepository : Repository<EquipoFitness>, IEquipoFitnessRepository
{
    public EquipoFitnessRepository(ApplicationDbContext context)
        : base(context)
    {
    }

    public Task<EquipoFitness?> GetByIdAsync(long id)
    {
        return DbContext.EquipoFitnessess
            .FirstOrDefaultAsync(x => x.Id == id);
    }
}
