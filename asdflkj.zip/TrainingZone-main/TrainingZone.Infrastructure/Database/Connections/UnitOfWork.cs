﻿using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Infrastructure.Database;

namespace TrainingZone.Infrastructure.Persistence.Connections;

public sealed class UnitOfWork : IUnitOfWork
{
    private readonly ApplicationDbContext _dbContext;

    public UnitOfWork(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
