﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Infrastructure.Database;

public class ApplicationDbContext : IdentityDbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, IPublisher publisher)
    : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<IdentityUser>(b =>
        {
            b.ToTable("Usuarios");
        });

        builder.Entity<IdentityUserClaim<string>>(b =>
        {
            b.ToTable("UsuarioClaims");
        });

        builder.Entity<IdentityUserLogin<string>>(b =>
        {
            b.ToTable("UsuarioLogins");
        });

        builder.Entity<IdentityUserToken<string>>(b =>
        {
            b.ToTable("UsuarioTokens");
        });

        builder.Entity<IdentityRole>(b =>
        {
            b.ToTable("Roles");
        });

        builder.Entity<IdentityRoleClaim<string>>(b =>
        {
            b.ToTable("RoleClaims");
        });

        builder.Entity<IdentityUserRole<string>>(b =>
        {
            b.ToTable("UsuarioRoles");
        });

        builder.Entity<Categoria>(b =>
        {
            b.ToTable("Categoria");
        });

        builder.Entity<EquipoFitness>(b =>
        {
            b.ToTable("EquipoFitness");
        });

        builder.Entity<Membresia>(b =>
        {
            b.ToTable("Membresia");
        });

        builder.Entity<Pago>(b =>
        {
            b.ToTable("Pago");
        });

        builder.Entity<ArVideo>(b =>
        {
            b.ToTable("ArVideo");
        });

        builder.Entity<Peso>(b =>
        {
            b.ToTable("Peso");
        });

        builder.Entity<AppUsuario>().Property(u => u.Genero).HasMaxLength(30);

        // Relaciones ER
        builder.Entity<Categoria>()
        .HasMany(c => c.EquipoFitnesses)             // Categoria has many EquipoFitnesses
        .WithOne(ef => ef.Categoria)                 // EquipoFitnesses has one Categoria
        .HasForeignKey(ef => ef.CategoriaID);        // Foreign key is CategoriaID in EquipoFitnesses
    }

    public DbSet<AppUsuario> AppUsuarios { get; set; }
    public DbSet<Peso> Pesos { get; set; }
    public DbSet<AppRole> AppRoles { get; set; }
    public DbSet<Categoria> Categorias { get; set; }
    public DbSet<EquipoFitness> EquipoFitnessess { get; set; }
    public DbSet<Membresia> Membresias { get; set; }
    public DbSet<Pago> Pagos { get; set; }
    public DbSet<ArVideo> ArVideos { get; set; }

    /*public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var domainEvents = ChangeTracker.Entries<Entity>()
            .Select(e => e.Entity.DomainEvents)
            .Where(e => e.DomainEvents)
            .SelectMany(e => e);

        // Before
        var result = await base.SaveChangesAsync(cancellationToken);
        
        foreach (var domainEvent in domainEvents)
        {
            await _publisher.Publish(domainEvents, cancellationToken);
        }

        return result;
    }*/
}
