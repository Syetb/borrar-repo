﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TrainingZone.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ChangedAppIdFK : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Membresia_Usuarios_AppUsuarioId",
                table: "Membresia");

            migrationBuilder.DropColumn(
                name: "AppUsuarioID",
                table: "Membresia");

            migrationBuilder.RenameColumn(
                name: "AppUsuarioId",
                table: "Membresia",
                newName: "AppUsuarioID");

            migrationBuilder.RenameIndex(
                name: "IX_Membresia_AppUsuarioId",
                table: "Membresia",
                newName: "IX_Membresia_AppUsuarioID");

            migrationBuilder.AlterColumn<string>(
                name: "AppUsuarioID",
                table: "Membresia",
                type: "text",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Membresia_Usuarios_AppUsuarioID",
                table: "Membresia",
                column: "AppUsuarioID",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Membresia_Usuarios_AppUsuarioID",
                table: "Membresia");

            migrationBuilder.RenameColumn(
                name: "AppUsuarioID",
                table: "Membresia",
                newName: "AppUsuarioId");

            migrationBuilder.RenameIndex(
                name: "IX_Membresia_AppUsuarioID",
                table: "Membresia",
                newName: "IX_Membresia_AppUsuarioId");

            migrationBuilder.AlterColumn<string>(
                name: "AppUsuarioId",
                table: "Membresia",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<long>(
                name: "AppUsuarioID",
                table: "Membresia",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddForeignKey(
                name: "FK_Membresia_Usuarios_AppUsuarioId",
                table: "Membresia",
                column: "AppUsuarioId",
                principalTable: "Usuarios",
                principalColumn: "Id");
        }
    }
}
