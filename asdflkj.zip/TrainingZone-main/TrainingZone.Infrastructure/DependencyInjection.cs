﻿using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Infrastructure.Persistence.Connections;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using TrainingZone.Infrastructure.Database;
using TrainingZone.Domain.Interfaces.Repositories;
using TrainingZone.Infrastructure.Database.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        // Configuración de Entity Framework Core
        services.AddDbContext<ApplicationDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("Database")));
        // Configuración de Autenticación y Autorización
        services.AddAuthentication();
        services.AddAuthorization();
        // Configuración de Identity Core
        services
            .AddIdentityApiEndpoints<AppUsuario>()
            .AddRoles<AppRole>()
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddSignInManager()
            .AddRoleManager<RoleManager<AppRole>>()
            .AddDefaultTokenProviders();

        services.Configure<IdentityOptions>(options =>
        {
            // Password settings.
            options.Password.RequireDigit = true;
            options.Password.RequireLowercase = true;
            options.Password.RequireNonAlphanumeric = true;
            options.Password.RequireUppercase = true;
            options.Password.RequiredLength = 6;
            options.Password.RequiredUniqueChars = 1;

            // Lockout settings.
            options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
            options.Lockout.MaxFailedAccessAttempts = 5;
            options.Lockout.AllowedForNewUsers = true;

            // User settings.
            options.User.AllowedUserNameCharacters =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+";
            options.User.RequireUniqueEmail = true;


        });


        // Register Repository Pattern
        services.AddScoped(typeof(IAppRoleRepository), typeof(AppRoleRepository));
        services.AddScoped(typeof(IAppUsuarioRepository), typeof(AppUsuarioRepository));
        services.AddScoped(typeof(IPesoRepository), typeof(PesoRepository));
        services.AddScoped(typeof(ICategoriaRepository), typeof(CategoriaRepository));
        services.AddScoped(typeof(IEquipoFitnessRepository), typeof(EquipoFitnessRepository));
        services.AddScoped(typeof(IArVideoRepository), typeof(ArVideoRepository));
        services.AddScoped(typeof(IMembresiaRepository), typeof(MembresiaRepository));
        services.AddScoped(typeof(IPagoRepository), typeof(PagoRepository));
        // Register UnitOfWork Pattern
        services.AddTransient<IUnitOfWork, UnitOfWork>();


        return services;
    }
}
