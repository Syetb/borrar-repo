﻿using TrainingZone.Domain.Common;

namespace TrainingZone.Domain.Entities;

public class Membresia : BaseEntity
{
    public string Tipo { get; set; } = default!;
    public DateTime FechaInicio { get; set; }
    public DateTime FechaFin { get; set; }
    public string Estado { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public string AppUsuarioID { get; set; } = default!;
    public AppUsuario AppUsuario { get; set; } = default!;

    public ICollection<Pago> Pagos { get; set; } = [];
}
