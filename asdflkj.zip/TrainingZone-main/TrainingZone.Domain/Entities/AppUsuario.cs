﻿using Microsoft.AspNetCore.Identity;

namespace TrainingZone.Domain.Entities;

public class AppUsuario : IdentityUser
{
    public string Nombre { get; set; } = default!;
    public string Apellido { get; set; } = default!;
    public string Genero { get; set; } = default!;
    public string? Image { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public ICollection<Membresia> Membresias { get; set; } = [];
    public ICollection<Peso> Pesos { get; set; } = [];
}