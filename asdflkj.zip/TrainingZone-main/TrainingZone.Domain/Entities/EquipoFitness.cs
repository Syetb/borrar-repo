﻿using TrainingZone.Domain.Common;

namespace TrainingZone.Domain.Entities;

public class EquipoFitness : BaseEntity
{
    public string Nombre { get; set; } = default!;
    public int Cantidad { get; set; }
    public string Imagen { get; set; } = default!;
    public string Instruccion { get; set; } = default!;
    public string Detalle { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public long CategoriaID { get; set; }
    public Categoria Categoria { get; set; } = default!;

    public ICollection<ArVideo> ArVideos { get; set; } = [];
}
