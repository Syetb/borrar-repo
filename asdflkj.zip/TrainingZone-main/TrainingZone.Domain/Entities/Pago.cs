﻿using TrainingZone.Domain.Common;

namespace TrainingZone.Domain.Entities;

public class Pago : BaseEntity
{
    public string EstadoPago { get; set; } = default!;
    public DateTime FechaPago { get; set; }
    public double Precio {  get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public long MembresiaID { get; set; }
    public Membresia Membresia { get; set; } = default!;
}
