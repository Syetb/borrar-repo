﻿using TrainingZone.Domain.Common;

namespace TrainingZone.Domain.Entities;

public class Categoria : BaseEntity
{
    public string Nombre { get; set; } = default!;
    public string Icono { get; set; } = default!;
    public string Descripcion { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public ICollection<EquipoFitness> EquipoFitnesses { get; set; } = [];
}
