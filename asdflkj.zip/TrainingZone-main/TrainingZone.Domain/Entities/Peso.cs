﻿using TrainingZone.Domain.Common;

namespace TrainingZone.Domain.Entities;

public class Peso : BaseEntity
{
    public float PesoActual { get; set; }
    public DateTime FechaRegistro { get; set; } = DateTime.UtcNow;
    public string AppUsuarioID { get; set; } = default!;
    public AppUsuario AppUsuario { get; set; } = default!;
}
