﻿using TrainingZone.Domain.Common;

namespace TrainingZone.Domain.Entities;

public class ArVideo : BaseEntity
{
    public string Nombre { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public long EquipoFitnessID { get; set; }
    public EquipoFitness EquipoFitness { get; set; } = default!;
}
