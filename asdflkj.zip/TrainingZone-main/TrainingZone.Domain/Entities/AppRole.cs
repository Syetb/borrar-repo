﻿using Microsoft.AspNetCore.Identity;

namespace TrainingZone.Domain.Entities;

public class AppRole : IdentityRole
{
    public string Descripcion { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}