﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Dto
{
    public class EquipoFitnessDto
    {
        public long Id { get; set; }
        public string Nombre { get; set; } = default!;
        public int Cantidad { get; set; }
        public string Imagen { get; set; } = default!;
        public string Instruccion { get; set; } = default!;
        public string Detalle { get; set; } = default!;
        public Categoria Categoria { get; set; } = default!;
    }
}
