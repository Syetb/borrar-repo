﻿namespace TrainingZone.Domain.Dto;

public class RoleDto
{
    public string Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
}
