﻿
namespace TrainingZone.Domain.Dto;

public class UsuarioDto
{
    public string Id { get; set; } = default!;
    public string Nombre { get; set; } = default!;
    public string Apellido { get; set; } = default!;
    public string Email { get; set; } = default!;
    public string Telefono { get; set; } = default!;
    public float Peso { get; set; }
    public string Genero { get; set; } = default!;
    public string? Image { get; set; } = default!;
    public string? Membresia { get; set; } = default!;
    public IList<string> Roles { get; set; } = default!;
}
