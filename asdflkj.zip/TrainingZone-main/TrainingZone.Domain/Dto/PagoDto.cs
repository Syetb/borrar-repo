﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Dto
{
    public class PagoDto
    {
        public long Id { get; set; }
        public string EstadoPago { get; set; } = default!;
        public DateTime FechaPago { get; set; }
        public double Precio { get; set; }

        public long MembresiaID { get; set; }
        public Membresia Membresia { get; set; } = default!;
    }
}
