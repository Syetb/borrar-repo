﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Dto
{
    public class ArVideoDto
    {
        public long Id { get; set; }
        public string Nombre { get; set; } = default!;
        public EquipoFitness EquipoFitness { get; set; } = default!;
    }
}
