﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Dto
{
    public class MembresiaDto
    {
        public long Id { get; set; }
        public string Tipo { get; set; } = default!;
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Estado { get; set; } = default!;
        public string AppUsuarioID { get; set; }
        //public PagoDto? Pago { get; set; }

        public ICollection<Pago> Pagos { get; set; } = [];
    }
}
