﻿namespace TrainingZone.Domain.Dto;

public class PesoDto
{
    public long Id { get; set; }
    public float PesoActual { get; set; }
    public DateTime FechaRegistro { get; set; } = DateTime.UtcNow;
}
