﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Dto;

public class CategoriaDto
{
    public long Id { get; set; }
    public string Nombre { get; set; } = default!;
    public string Icono { get; set; } = default!;
    public string Descripcion { get; set; } = default!;
    public ICollection<EquipoFitness> EquipoFitnesses { get; set; } = [];
}