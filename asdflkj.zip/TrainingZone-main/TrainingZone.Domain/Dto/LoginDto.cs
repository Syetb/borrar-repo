﻿
namespace TrainingZone.Domain.Dto
{
    public class LoginDto
    {
        public UsuarioDto Usuario { get; set; } = default!;
        public TokenDto Token { get; set; } = default!;
    }
}
