﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IAppUsuarioRepository
{   
    Task<AppUsuario?> GetByIdAsync(string userId, CancellationToken cancellationToken = default);

    Task<List<AppUsuario>> GetAllAsync(CancellationToken cancellationToken = default);
}
