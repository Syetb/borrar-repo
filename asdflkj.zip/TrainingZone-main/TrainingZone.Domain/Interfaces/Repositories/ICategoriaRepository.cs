﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface ICategoriaRepository
{
    Task<List<Categoria>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Categoria?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    void Add(Categoria categoria);
    void Update(Categoria categoria);
    public void Remove(Categoria categoria);
}
