﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IMembresiaRepository
{
    Task<List<Membresia>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Membresia?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    void Add(Membresia membresia);
    void Update(Membresia membresia);
    public void Remove(Membresia membresia);
}
