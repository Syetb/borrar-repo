﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IArVideoRepository
{
    Task<List<ArVideo>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<ArVideo?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    void Add(ArVideo arVideo);
    void Update(ArVideo arVideo);
    public void Remove(ArVideo arVideo);

}
