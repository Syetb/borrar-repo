﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IAppRoleRepository
{
    Task<AppRole?> GetByIdAsync(string id);
}
