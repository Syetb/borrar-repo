﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IPagoRepository
{
    Task<List<Pago>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Pago?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    void Add(Pago pago);
    void Update(Pago pago);
    public void Remove(Pago pago);
}
