﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IPesoRepository
{
    Task<List<Peso>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<List<Peso>> GetPesoByUserIdAsync(string userId, int intervalo = 3, CancellationToken cancellationToken = default);
    Task<Peso?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    void Add(Peso peso);
    void Update(Peso peso);
    public void Remove(Peso peso);
}
