﻿using TrainingZone.Domain.Entities;

namespace TrainingZone.Domain.Interfaces.Repositories;

public interface IEquipoFitnessRepository
{
    Task<List<EquipoFitness>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<EquipoFitness?> GetByIdAsync(long id, CancellationToken cancellationToken = default);
    void Add(EquipoFitness equipoFitness);
    void Update(EquipoFitness equipoFitness);
    public void Remove(EquipoFitness equipoFitness);
}
