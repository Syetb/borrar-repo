﻿
namespace TrainingZone.Domain.Common;

public abstract class BaseEntity
{
    public long Id { get; set; }
}
