﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.EquipoFitnesses.Queries.GetByIdEquipoFitness;

public class GetByIdEquipoFitnessQuery : IRequestWrapper<EquipoFitnessDto>
{
    public long Id { get; set; } = default!;
}

public class GetByIdEquipoFitnessQueryHandler : IRequestHandlerWrapper<GetByIdEquipoFitnessQuery, EquipoFitnessDto>
{
    private readonly IEquipoFitnessRepository _equipoFitnessRepository;

    public GetByIdEquipoFitnessQueryHandler(IEquipoFitnessRepository equipoFitnessRepository)
    {
        _equipoFitnessRepository = equipoFitnessRepository;
    }

    public async Task<ApiResponse<EquipoFitnessDto>> Handle(GetByIdEquipoFitnessQuery request, CancellationToken token)
    {
        var equipoFitness = await _equipoFitnessRepository.GetByIdAsync(request.Id, token);
        // Verifica si la categoría existe
        if (equipoFitness == null)
        {
            return new ApiResponse<EquipoFitnessDto>
            {
                Data = null
            };
        }

        return ApiResponse.Success(new EquipoFitnessDto
        {
            Id = equipoFitness.Id,
            Nombre = equipoFitness.Nombre,
            Cantidad = equipoFitness.Cantidad,
            Imagen = equipoFitness.Imagen,
            Instruccion = equipoFitness.Instruccion,
            Detalle = equipoFitness.Detalle,
            Categoria = equipoFitness.Categoria
        });
    }
}
