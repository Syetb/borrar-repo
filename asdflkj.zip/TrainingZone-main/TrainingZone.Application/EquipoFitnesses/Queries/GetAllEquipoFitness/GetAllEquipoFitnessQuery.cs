﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.EquipoFitnesses.Queries.GetAllEquipoFitness;

public class GetAllEquipoFitnessQuery : IRequestWrapper<List<EquipoFitnessDto>>
{
}

public class GetAllEquipoFitnessQueryHandler : IRequestHandlerWrapper<GetAllEquipoFitnessQuery, List<EquipoFitnessDto>>
{
    private readonly IEquipoFitnessRepository _equipoFitnessRepository;

    public GetAllEquipoFitnessQueryHandler(IEquipoFitnessRepository equipoFitnessRepository)
    {
        _equipoFitnessRepository = equipoFitnessRepository;
    }

    public async Task<ApiResponse<List<EquipoFitnessDto>>> Handle(GetAllEquipoFitnessQuery request, CancellationToken token)
    {
        var equipoFitnesses = await _equipoFitnessRepository.GetAllAsync(token);
        var equiposFitnessDto = new List<EquipoFitnessDto>();

        foreach (var equipoFitness in equipoFitnesses)
        {
            var equipoFitnessDto = new EquipoFitnessDto
            {
                Id = equipoFitness.Id,
                Nombre = equipoFitness.Nombre,
                Cantidad = equipoFitness.Cantidad,
                Imagen  = equipoFitness.Imagen,
                Instruccion = equipoFitness.Instruccion,
                Detalle = equipoFitness.Detalle,
                Categoria = equipoFitness.Categoria,
            };

            equiposFitnessDto.Add(equipoFitnessDto);
        }

        return new ApiResponse<List<EquipoFitnessDto>>
        {
            Data = equiposFitnessDto
        };
    }
}
