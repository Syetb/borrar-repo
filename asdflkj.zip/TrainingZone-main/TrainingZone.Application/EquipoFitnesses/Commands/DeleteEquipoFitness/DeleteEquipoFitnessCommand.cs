﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.EquipoFitnesses.Commands.DeleteEquipoFitness;

public class DeleteEquipoFitnessCommand : IRequestWrapper<EquipoFitnessDto>
{
    public long Id { get; set; }
}

public class DeleteEquipoFitnessCommandHandler : IRequestHandlerWrapper<DeleteEquipoFitnessCommand, EquipoFitnessDto>
{
    private readonly IEquipoFitnessRepository _equipoFitnessRepository;
    private readonly IUnitOfWork _unitOfWork;

    public DeleteEquipoFitnessCommandHandler(IEquipoFitnessRepository herramientaFitnessRepository, IUnitOfWork unitOfWork)
    {
        _equipoFitnessRepository = herramientaFitnessRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<EquipoFitnessDto>> Handle(DeleteEquipoFitnessCommand request, CancellationToken token)
    {
        var equipoFitness = await _equipoFitnessRepository.GetByIdAsync(request.Id, token);
        if (equipoFitness == null)
        {
            return new ApiResponse<EquipoFitnessDto>(new EquipoFitnessDto());
        }

        _equipoFitnessRepository.Remove(equipoFitness);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<EquipoFitnessDto>(new EquipoFitnessDto
        {
            Id = equipoFitness.Id
        });
    }
}
