﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.EquipoFitnesses.Commands.CreateEquipoFitness;

public class CreateEquipoFitnessCommand : IRequestWrapper<EquipoFitnessDto>
{
    public string Nombre { get; set; } = default!;
    public int Cantidad { get; set; }
    public string Imagen { get; set; } = default!;
    public string Instruccion { get; set; } = default!;
    public string Detalle { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public long CategoriaID { get; set; }
}

public class CreateCategoriaCommandHandler : IRequestHandlerWrapper<CreateEquipoFitnessCommand, EquipoFitnessDto>
{
    private readonly IEquipoFitnessRepository _equipoFitnessRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateCategoriaCommandHandler(IEquipoFitnessRepository equipoFitnessRepository, IUnitOfWork unitOfWork)
    {
        _equipoFitnessRepository = equipoFitnessRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<EquipoFitnessDto>> Handle(CreateEquipoFitnessCommand request, CancellationToken token)
    {
        var categoria = new EquipoFitness
        {
            Nombre = request.Nombre,
            Cantidad = request.Cantidad,
            Imagen = request.Imagen,
            Instruccion = request.Instruccion,
            Detalle = request.Detalle,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _equipoFitnessRepository.Add(categoria);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<EquipoFitnessDto>(new EquipoFitnessDto
        {
            Id = categoria.Id,
            Nombre = categoria.Nombre,
            Cantidad = categoria.Cantidad,
            Imagen = categoria.Imagen,
            Instruccion = categoria.Instruccion,
            Detalle = categoria.Detalle 
        });
    }
}
