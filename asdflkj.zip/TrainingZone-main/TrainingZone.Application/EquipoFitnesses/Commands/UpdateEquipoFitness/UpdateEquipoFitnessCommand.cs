﻿
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.EquipoFitnesses.Commands.UpdateEquipoFitness;

public class UpdateEquipoFitnessCommand : IRequestWrapper<EquipoFitnessDto>
{
    public long Id { get; set; }
    public string Nombre { get; set; } = default!;
    public int Cantidad { get; set; }
    public string Imagen { get; set; } = default!;
    public string Instruccion { get; set; } = default!;
    public string Detalle { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    public long CategoriaID { get; set; }
}

public class CreateCategoriaCommandHandler : IRequestHandlerWrapper<UpdateEquipoFitnessCommand, EquipoFitnessDto>
{
    private readonly IEquipoFitnessRepository _equipoFitnessRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateCategoriaCommandHandler(IEquipoFitnessRepository equipoFitnessRepository, IUnitOfWork unitOfWork)
    {
        _equipoFitnessRepository = equipoFitnessRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<EquipoFitnessDto>> Handle(UpdateEquipoFitnessCommand request, CancellationToken token)
    {
        var equipoFitness = await _equipoFitnessRepository.GetByIdAsync(request.Id, token);
        if (equipoFitness == null)
        {
            return new ApiResponse<EquipoFitnessDto>(new EquipoFitnessDto());
        }

        var equipoFitnessUpd = new EquipoFitness
        {
            Nombre = request.Nombre,
            Cantidad = request.Cantidad,
            Imagen = request.Imagen,
            Instruccion = request.Instruccion,
            Detalle = request.Detalle,
            UpdatedAt = request.UpdatedAt
        };

        _equipoFitnessRepository.Update(equipoFitnessUpd);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<EquipoFitnessDto>(new EquipoFitnessDto
        {
            Id = equipoFitnessUpd.Id,
            Nombre = equipoFitnessUpd.Nombre,
            Cantidad = equipoFitnessUpd.Cantidad,
            Imagen = equipoFitnessUpd.Imagen,
            Instruccion = equipoFitnessUpd.Instruccion,
            Detalle = equipoFitnessUpd.Detalle
        });
    }
}
