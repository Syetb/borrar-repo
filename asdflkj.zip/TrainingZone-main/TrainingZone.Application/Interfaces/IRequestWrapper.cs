﻿using TrainingZone.Application.Common.Models;
using MediatR;

namespace TrainingZone.Application.Interfaces;

public interface IRequestWrapper<T> : IRequest<ApiResponse<T>>
{
}

public interface IRequestHandlerWrapper<TIn, TOut> : IRequestHandler<TIn, ApiResponse<TOut>> where TIn : IRequestWrapper<TOut>
{
}
