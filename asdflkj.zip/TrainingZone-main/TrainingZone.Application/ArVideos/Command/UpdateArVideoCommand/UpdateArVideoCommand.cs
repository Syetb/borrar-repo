﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.ArVideos.Command.UpdateArVideoCommand;

public class UpdateArVideoCommand : IRequestWrapper<ArVideoDto>
{
    public long Id { get; set; }
    public string Nombre { get; set; } = default!;
}

public class UpdateArVideoCommandHandler : IRequestHandlerWrapper<UpdateArVideoCommand, ArVideoDto>
{
    private readonly IArVideoRepository _arVideoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public UpdateArVideoCommandHandler(IArVideoRepository arVideoRepository, IUnitOfWork unitOfWork)
    {
        _arVideoRepository = arVideoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<ArVideoDto>> Handle(UpdateArVideoCommand request, CancellationToken token)
    {
        var arVideo = await _arVideoRepository.GetByIdAsync(request.Id, token);
        if (arVideo == null)
        {
            return new ApiResponse<ArVideoDto>(new ArVideoDto());
        }

        var arVideoUpd = new ArVideo
        {
            Nombre = request.Nombre,
            UpdatedAt = DateTime.UtcNow,
        };

        _arVideoRepository.Update(arVideoUpd);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<ArVideoDto>(new ArVideoDto
        {
            Id = arVideo.Id,
            Nombre = arVideo.Nombre,
        });
    }
}
