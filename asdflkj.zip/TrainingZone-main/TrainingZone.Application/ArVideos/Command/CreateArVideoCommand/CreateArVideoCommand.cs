﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.ArVideos.Command.CreateArVideoCommand;

public class CreateArVideoCommand : IRequestWrapper<ArVideoDto>
{
    public string Nombre { get; set; } = default!;
    public long EquipoFitnessID { get; set; }
}

public class CreateArVideoCommandHandler : IRequestHandlerWrapper<CreateArVideoCommand, ArVideoDto>
{
    private readonly IArVideoRepository _arVideoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateArVideoCommandHandler(IArVideoRepository arVideoRepository, IUnitOfWork unitOfWork)
    {
        _arVideoRepository = arVideoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<ArVideoDto>> Handle(CreateArVideoCommand request, CancellationToken token)
    {
        var arVideo = new ArVideo
        {
            Nombre = request.Nombre,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
        };

        _arVideoRepository.Add(arVideo);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<ArVideoDto>(new ArVideoDto
        {
            Id = arVideo.Id,
            Nombre = arVideo.Nombre
        });
    }
}
