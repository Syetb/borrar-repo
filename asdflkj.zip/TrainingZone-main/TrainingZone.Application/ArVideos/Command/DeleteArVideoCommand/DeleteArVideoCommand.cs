﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.ArVideos.Command.DeleteArVideoCommand;

public class DeleteArVideoCommand : IRequestWrapper<ArVideoDto>
{
    public long Id { get; set; }
}

public class DeleteArVideoCommandHandler : IRequestHandlerWrapper<DeleteArVideoCommand, ArVideoDto>
{
    private readonly IArVideoRepository _arVideoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public DeleteArVideoCommandHandler(IArVideoRepository arVideoRepository, IUnitOfWork unitOfWork)
    {
        _arVideoRepository = arVideoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<ArVideoDto>> Handle(DeleteArVideoCommand request, CancellationToken token)
    {
        var arVideo = await _arVideoRepository.GetByIdAsync(request.Id, token);
        if (arVideo == null)
        {
            return new ApiResponse<ArVideoDto>(new ArVideoDto());
        }

        _arVideoRepository.Remove(arVideo);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<ArVideoDto>(new ArVideoDto
        {
            Id = arVideo.Id
        });
    }
}
