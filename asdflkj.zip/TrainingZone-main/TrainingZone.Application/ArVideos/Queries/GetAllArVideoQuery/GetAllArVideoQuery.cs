﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.ArVideos.Queries.GetAllArVideoQuery;

public class GetAllArVideoQuery : IRequestWrapper<List<ArVideoDto>>
{
}

public class GetAllArVideoQueryHandler : IRequestHandlerWrapper<GetAllArVideoQuery, List<ArVideoDto>>
{
    private readonly IArVideoRepository _arVideoRepository;

    public GetAllArVideoQueryHandler(IArVideoRepository arVideoRepository)
    {
        _arVideoRepository = arVideoRepository;
    }

    public async Task<ApiResponse<List<ArVideoDto>>> Handle(GetAllArVideoQuery request, CancellationToken token)
    {
        var arVideos = await _arVideoRepository.GetAllAsync(token);
        var arVideosDto = new List<ArVideoDto>();

        foreach (var arVideo in arVideos)
        {
            var arVideoDto = new ArVideoDto
            {
                Id = arVideo.Id,
                Nombre = arVideo.Nombre
            };

            arVideosDto.Add(arVideoDto);
        }

        return new ApiResponse<List<ArVideoDto>>
        {
            Data = arVideosDto
        };
    }
}