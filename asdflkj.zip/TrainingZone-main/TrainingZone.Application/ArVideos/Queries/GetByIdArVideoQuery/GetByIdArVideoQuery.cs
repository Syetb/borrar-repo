﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.ArVideos.Queries.GetByIdArVideoQuery;

public class GetByIdArVideoQuery : IRequestWrapper<ArVideoDto>
{
    public long Id { get; set; } = default!;
}

public class GetByIdArVideoQueryHandler : IRequestHandlerWrapper<GetByIdArVideoQuery, ArVideoDto>
{
    private readonly IArVideoRepository _arVideoRepository;

    public GetByIdArVideoQueryHandler(IArVideoRepository arVideoRepository)
    {
        _arVideoRepository = arVideoRepository;
    }

    public async Task<ApiResponse<ArVideoDto>> Handle(GetByIdArVideoQuery request, CancellationToken token)
    {
        var arVideo = await _arVideoRepository.GetByIdAsync(request.Id, token);
        // Verifica si la categoría existe
        if (arVideo == null)
        {
            return new ApiResponse<ArVideoDto>
            {
                Data = null
            };
        }

        return ApiResponse.Success(new ArVideoDto
        {
            Id = arVideo.Id,
            Nombre = arVideo.Nombre
        });
    }
}
