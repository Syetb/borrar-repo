﻿using ApplicationException = TrainingZone.Domain.Exceptions.ApplicationException;

namespace TrainingZone.Application.Common.Exceptions;

public sealed class ValidationException : ApplicationException
{
    public ValidationException(IReadOnlyDictionary<string, string[]> failures)
        : base("Validation Failure", "One or more validation errors occurred")
        => Errors = failures;

    public IReadOnlyDictionary<string, string[]> Errors { get; }
}
