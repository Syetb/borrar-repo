﻿namespace TrainingZone.Application.Common.Models;

/// <summary>
/// A standard response for service calls.
/// </summary>
/// <typeparam name="T">Return data type</typeparam>
public class ApiResponse<T> : ApiResponse
{
    public T Data { get; set; }

    public ApiResponse()
    {
    }

    public ApiResponse(T data)
    {
        Data = data;
    }

    public ApiResponse(T data, ApiError error) : base(error)
    {
        Data = data;
    }

    public ApiResponse(ApiError error) : base(error)
    {

    }
}

public class ApiResponse
{
    public bool Succeeded => this.Error == null;

    public ApiError Error { get; set; }

    public ApiResponse(ApiError error)
    {
        if (error == null)
        {
            error = ApiError.DefaultError;
        }

        Error = error;
    }

    public ApiResponse() { }

    #region Helper Methods

    public static ApiResponse Failed(ApiError error)
    {
        return new ApiResponse(error);
    }

    public static ApiResponse<T> Failed<T>(T error)
    {
        return new ApiResponse<T>(error);
    }

    public static ApiResponse<T> Failed<T>(T data, ApiError error)
    {
        return new ApiResponse<T>(data, error);
    }

    public static ApiResponse<T> Success<T>(T data)
    {
        return new ApiResponse<T>(data);
    }

    #endregion
}
