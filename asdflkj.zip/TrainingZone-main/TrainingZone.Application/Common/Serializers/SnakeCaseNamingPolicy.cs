﻿using System.Text.Json;

namespace TrainingZone.Application.Common.Serializers;

public sealed class SnakeCaseNamingPolicy : JsonNamingPolicy
{
    public override string ConvertName(string name) => name.ToSnakeCase();
}
