﻿using Microsoft.AspNetCore.Identity;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Application.Roles.Commands.DeleteRoleCommand
{
    public class DeleteRoleCommand : IRequestWrapper<string>
    {
        public string RoleId { get; set; } = default!;
    }

    public class DeleteUserCommandHandler : IRequestHandlerWrapper<DeleteRoleCommand, string>
    {
        private readonly RoleManager<AppRole> _roleManager;

        public DeleteUserCommandHandler(RoleManager<AppRole> roleManager)
        {
            _roleManager = roleManager;
        }

        public async Task<ApiResponse<string>> Handle(DeleteRoleCommand request, CancellationToken token)
        {
            // Buscar al role por su ID
            var role = await _roleManager.FindByIdAsync(request.RoleId);

            if (role != null)
            {
                // Si el usuario existe, procedemos a eliminarlo
                var result = await _roleManager.DeleteAsync(role);

                if (!result.Succeeded)
                {
                    return ApiResponse.Failed($"ERROR ${result.Errors}");
                }

                return ApiResponse.Success("Delete successful");
            }
            else
            {
                return ApiResponse.Failed($"ERROR NOFOUND");
            }
        }
    }
}
