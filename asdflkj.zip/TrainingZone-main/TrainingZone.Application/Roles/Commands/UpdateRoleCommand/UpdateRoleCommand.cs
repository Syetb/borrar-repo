﻿using Microsoft.AspNetCore.Identity;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Application.Roles.Commands.UpdateRoleCommand
{
    public class UpdateRoleCommand : IRequestWrapper<string>
    {
        public string RoleId { get; set; } = default!;
        public string Nombre { get; set; } = default!;
        public string Descripcion { get; set; } = default!;
    }

    public class UpdateRoleCommandHandler : IRequestHandlerWrapper<UpdateRoleCommand, string>
    {
        private readonly RoleManager<AppRole> _roleManager;

        public UpdateRoleCommandHandler(RoleManager<AppRole> roleManager)
        {
            _roleManager = roleManager;
        }

        public async Task<ApiResponse<string>> Handle(UpdateRoleCommand request, CancellationToken token)
        {
            var role = new AppRole
            { 
                Id = request.RoleId,
                Name = request.Nombre,
                Descripcion = request.Nombre,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
            };

            var result = await _roleManager.UpdateAsync(role);

            if (!result.Succeeded)
            {
                return ApiResponse.Failed($"ERROR ${result.Errors}");
            }

            return ApiResponse.Success("Registration successful");
        }
    }
}
