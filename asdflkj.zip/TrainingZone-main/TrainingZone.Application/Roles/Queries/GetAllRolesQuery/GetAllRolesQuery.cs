﻿using Microsoft.AspNetCore.Identity;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Application.Roles.Queries.GetAllRolesQuery;

public class GetAllRolesQuery : IRequestWrapper<List<RoleDto>>
{
}

public class GetAllRolesQueryHandler : IRequestHandlerWrapper<GetAllRolesQuery, List<RoleDto>>
{
    private readonly RoleManager<AppRole> _roleManager;

    public GetAllRolesQueryHandler(RoleManager<AppRole> roleManager)
    {
        _roleManager = roleManager;
    }

    public async Task<ApiResponse<List<RoleDto>>> Handle(GetAllRolesQuery request, CancellationToken token)
    {
        var roles = _roleManager.Roles.ToList();
        var rolesDto = new List<RoleDto>();

        foreach (var role in roles)
        {
            var roleDto = new RoleDto
            {
                Id = role.Id,
                Name = role.Name!,
                Descripcion = role.Descripcion
            };

            rolesDto.Add(roleDto);
        }

        return new ApiResponse<List<RoleDto>>
        {
            Data = rolesDto,
        };
    }
}
