﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Application.Roles.Queries.GetRoleByIdQuery;

public class GetRoleByIdQuery : IRequestWrapper<RoleDto>
{
    public string RoleId { get; set; } = default!;
}

public class GetRoleByIdQueryHandler : IRequestHandlerWrapper<GetRoleByIdQuery, RoleDto>
{
    private readonly RoleManager<AppRole> _roleManager;

    public GetRoleByIdQueryHandler(RoleManager<AppRole> roleManager)
    {
        _roleManager = roleManager;
    }

    public async Task<ApiResponse<RoleDto>> Handle(GetRoleByIdQuery request, CancellationToken token)
    {
        var role = await _roleManager.Roles
                .FirstAsync(x => x.Id == request.RoleId, token);

        if (role == null)
        {
            return ApiResponse.Failed(new RoleDto { Id = "", Name = "" });
        }

        return ApiResponse.Success(new RoleDto
        {
            Id = role.Id,
            Name = role.Name!,
            Descripcion = role.Descripcion
        });
    }
}
