﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pesos.Commands.CreatePesoCommand;

public class CreatePesoCommand : IRequestWrapper<PesoDto>
{
    public float PesoActual { get; set; } = default!;
    public string UserId { get; set; } = default!;
}

public class CreatePesoCommandHandler : IRequestHandlerWrapper<CreatePesoCommand, PesoDto>
{
    private readonly IPesoRepository _pesoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreatePesoCommandHandler(IPesoRepository pesoRepository, IUnitOfWork unitOfWork)
    {
        _pesoRepository = pesoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<PesoDto>> Handle(CreatePesoCommand request, CancellationToken token)
    {
        var peso = new Peso
        {
            PesoActual = request.PesoActual,
            FechaRegistro = DateTime.UtcNow,
            AppUsuarioID = request.UserId
        };

        _pesoRepository.Add(peso);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<PesoDto>(new PesoDto
        {
            Id = peso.Id,
            PesoActual = peso.PesoActual,
            FechaRegistro = peso.FechaRegistro,
        });
    }
}
