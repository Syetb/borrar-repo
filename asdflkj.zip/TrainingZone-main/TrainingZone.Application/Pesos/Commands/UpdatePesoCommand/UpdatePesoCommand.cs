﻿namespace TrainingZone.Application.Pesos.Commands.UpdatePesoCommand;

public class UpdatePesoCommand
{
}
