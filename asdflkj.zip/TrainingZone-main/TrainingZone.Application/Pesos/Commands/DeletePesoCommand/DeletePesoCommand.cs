﻿namespace TrainingZone.Application.Pesos.Commands.DeletePesoCommand;

public class DeletePesoCommand
{
}
