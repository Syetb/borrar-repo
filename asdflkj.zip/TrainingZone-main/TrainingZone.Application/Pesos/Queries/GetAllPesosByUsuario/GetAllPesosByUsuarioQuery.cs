﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pesos.Queries.GetAllPesosByUsuarioQuery;

public class GetAllPesosByUsuarioQuery : IRequestWrapper<List<PesoDto>>
{
    public string UserId { get; set; } = default!;
    public int Intervalo { get; set; }
}

public class GetAllPesosByUsuarioQueryHandler : IRequestHandlerWrapper<GetAllPesosByUsuarioQuery, List<PesoDto>>
{
    private readonly IPesoRepository _pesoRepository;

    public GetAllPesosByUsuarioQueryHandler(IPesoRepository pesoRepository)
    {
        _pesoRepository = pesoRepository;
    }

    public async Task<ApiResponse<List<PesoDto>>> Handle(GetAllPesosByUsuarioQuery request, CancellationToken token)
    {
        var pesos = await _pesoRepository.GetPesoByUserIdAsync(request.UserId, request.Intervalo, token);
        var pesosDto = new List<PesoDto>();

        foreach (var peso in pesos)
        {
            var pesoDto = new PesoDto
            {
                Id = peso.Id,
                PesoActual = peso.PesoActual,
                FechaRegistro = peso.FechaRegistro
            };

            pesosDto.Add(pesoDto);
        }

        return new ApiResponse<List<PesoDto>>
        {
            Data = pesosDto
        };
    }
}
