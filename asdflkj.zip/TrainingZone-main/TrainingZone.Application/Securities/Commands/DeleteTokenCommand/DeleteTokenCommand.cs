﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using Serilog;
using Microsoft.AspNetCore.Identity;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Application.Securities.Commands.DeleteTokenCommand;

public class DeleteTokenCommand : IRequestWrapper<string>
{
}

public class DeleteTokenCommandHandler : IRequestHandlerWrapper<DeleteTokenCommand, string>
{
    private readonly ILogger _logger;
    private readonly SignInManager<AppUsuario> _signInManager;

    public DeleteTokenCommandHandler(ILogger logger, SignInManager<AppUsuario> signInManager)
    {
        _logger = logger;
        _signInManager = signInManager;
    }

    public async Task<ApiResponse<string>> Handle(DeleteTokenCommand request, CancellationToken cancellationToken)
    {
        _logger.Information("Seri Log is Working");
        // Sign out the user
        await _signInManager.SignOutAsync();

        return ApiResponse.Success("User logged out successfully.");
    }
}
