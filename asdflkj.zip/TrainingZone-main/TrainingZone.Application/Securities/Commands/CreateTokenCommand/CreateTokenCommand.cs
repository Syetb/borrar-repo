﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Interfaces.Connections;
using Serilog;
using Microsoft.AspNetCore.Identity;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Services;
using Newtonsoft.Json.Linq;

namespace TrainingZone.Application.Securities.Commands;

public sealed class CreateTokenCommand : IRequestWrapper<LoginDto>
{
    public string Email { get; set; } = default!;
    public string Password { get; set; } = default!;
}

public sealed class CreateTokenCommandHandler : IRequestHandlerWrapper<CreateTokenCommand, LoginDto>
{
    private readonly ILogger _logger;
    private readonly IUnitOfWork _unitOfWork;
    private readonly UserManager<AppUsuario> _userManager;
    //private readonly ITokenService _token;

    public CreateTokenCommandHandler(ILogger logger, IUnitOfWork unitOfWork, UserManager<AppUsuario> userManager/*, ITokenService token*/)
    {
        _logger = logger;
        _unitOfWork = unitOfWork;
        _userManager = userManager;
        //_token = token;
    }

    public async Task<ApiResponse<LoginDto>> Handle(CreateTokenCommand request, CancellationToken cancellationToken)
    {
        var user = await _userManager.FindByNameAsync(request.Email);
        /*if (user != null && await _userManager.CheckPasswordAsync(user, request.Password))
        {
            //var token = _jwtService.GenerateToken(user.UserName);
            var token = await _token.GenerateAndStoreTokenAsync(user.UserName!);
            return ApiResponse.Success(new LoginDto { Token = token, Usuario = new UsuarioDto { Id = user.Id, Email = user.Email! } });
        }*/


        return ApiResponse.Failed(new LoginDto { Token = null });
    }
}
