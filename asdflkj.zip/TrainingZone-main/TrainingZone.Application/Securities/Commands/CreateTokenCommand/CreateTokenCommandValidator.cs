﻿using FluentValidation;

namespace TrainingZone.Application.Securities.Commands;

public sealed class CreateTokenCommandValidator : AbstractValidator<CreateTokenCommand>
{
    public CreateTokenCommandValidator()
    {
        RuleFor(v => v.Email)
            .NotEmpty()
            .MaximumLength(100).WithMessage("Invalid login_id");

        RuleFor(v => v.Password)
            .NotEmpty()
            .MinimumLength(8).WithMessage("Invalid password")
            .MaximumLength(100).WithMessage("Invalid password");
    }
}
