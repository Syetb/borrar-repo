﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Categorias.Queries.GetAllCategoriasQuery;

public class GetAllCategoriasQuery : IRequestWrapper<List<CategoriaDto>>
{
}

public class GetAllCategoriasQueryHandler : IRequestHandlerWrapper<GetAllCategoriasQuery, List<CategoriaDto>>
{
    private readonly ICategoriaRepository _categoriaRepository;

    public GetAllCategoriasQueryHandler(ICategoriaRepository categoriaRepository)
    {
        _categoriaRepository = categoriaRepository;
    }

    public async Task<ApiResponse<List<CategoriaDto>>> Handle(GetAllCategoriasQuery request, CancellationToken token)
    {
        var categorias = await _categoriaRepository.GetAllAsync(token);
        var categoriasDto = new List<CategoriaDto>();

        foreach (var categoria in categorias)
        {
           var categoriaDto = new CategoriaDto
            {
                Id = categoria.Id,
                Nombre = categoria.Nombre,
                Icono = categoria.Icono,
                Descripcion = categoria.Descripcion
            };

            categoriasDto.Add(categoriaDto);
        }

        return new ApiResponse<List<CategoriaDto>>
        {
            Data = categoriasDto
        };
    }
}
