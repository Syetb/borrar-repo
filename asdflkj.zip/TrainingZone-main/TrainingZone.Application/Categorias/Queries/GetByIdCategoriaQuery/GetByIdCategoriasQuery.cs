﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Categorias.Queries.GetByIdCategoriaQuery;

public class GetByIdCategoriasQuery : IRequestWrapper<CategoriaDto>
{
    public long Id { get; set; } = default!;
}

public class GetAllCategoriasQueryHandler : IRequestHandlerWrapper<GetByIdCategoriasQuery, CategoriaDto>
{
    private readonly ICategoriaRepository _categoriaRepository;

    public GetAllCategoriasQueryHandler(ICategoriaRepository categoriaRepository)
    {
        _categoriaRepository = categoriaRepository;
    }

    public async Task<ApiResponse<CategoriaDto>> Handle(GetByIdCategoriasQuery request, CancellationToken token)
    {
        var categoria = await _categoriaRepository.GetByIdAsync(request.Id, token);
        // Verifica si la categoría existe
        if (categoria == null)
        {
            return new ApiResponse<CategoriaDto>
            {
                Data = null
            };
        }

        return ApiResponse.Success(new CategoriaDto
        {
            Id = categoria.Id,
            Nombre = categoria.Nombre,
            Icono = categoria.Icono,
            Descripcion = categoria.Descripcion
        });
    }
}
