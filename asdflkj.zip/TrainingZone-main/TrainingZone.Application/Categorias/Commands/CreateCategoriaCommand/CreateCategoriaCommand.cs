﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Categorias.Commands.CreateCategoriaCommand;

public class CreateCategoriaCommand : IRequestWrapper<CategoriaDto>
{
    public string Nombre { get; set; } = default!;
    public string Icono { get; set; } = default!;
    public string Descripcion { get; set; } = default!;
}

public class CreateCategoriaCommandHandler : IRequestHandlerWrapper<CreateCategoriaCommand, CategoriaDto>
{
    private readonly ICategoriaRepository _categoriaRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateCategoriaCommandHandler(ICategoriaRepository categoriaRepository, IUnitOfWork unitOfWork)
    {
        _categoriaRepository = categoriaRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<CategoriaDto>> Handle(CreateCategoriaCommand request, CancellationToken token)
    {
        var categoria = new Categoria
        {
            Nombre = request.Nombre,
            Icono = request.Icono,
            Descripcion = request.Descripcion,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
        };

        _categoriaRepository.Add(categoria);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<CategoriaDto>(new CategoriaDto
        {
            Id = categoria.Id,
            Nombre = categoria.Nombre,
            Icono = categoria.Icono,
            Descripcion = categoria.Descripcion
        });
    }
}
