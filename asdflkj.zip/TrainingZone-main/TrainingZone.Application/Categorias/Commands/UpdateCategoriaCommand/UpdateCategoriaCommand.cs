﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Categorias.Commands.UpdateCategoriaCommand;

public class UpdateCategoriaCommand : IRequestWrapper<CategoriaDto>
{
    public long Id { get; set; }
    public string Nombre { get; set; } = default!;
    public string Icono { get; set; } = default!;
    public string Descripcion { get; set; } = default!;
}

public class CreateCategoriaCommandHandler : IRequestHandlerWrapper<UpdateCategoriaCommand, CategoriaDto>
{
    private readonly ICategoriaRepository _categoriaRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateCategoriaCommandHandler(ICategoriaRepository categoriaRepository, IUnitOfWork unitOfWork)
    {
        _categoriaRepository = categoriaRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<CategoriaDto>> Handle(UpdateCategoriaCommand request, CancellationToken token)
    {
        var categoria = await _categoriaRepository.GetByIdAsync(request.Id, token);
        if (categoria == null)
        {
            return new ApiResponse<CategoriaDto>(new CategoriaDto());
        }

        var categoriaUpd = new Categoria 
        {
            Nombre = request.Nombre,
            Icono = request.Icono,
            Descripcion = request.Descripcion,
            UpdatedAt = DateTime.UtcNow,
        };

        _categoriaRepository.Update(categoriaUpd); 
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<CategoriaDto>(new CategoriaDto
        {
            Id = categoria.Id,
            Nombre = categoria.Nombre,
            Icono = categoria.Icono,
            Descripcion = categoria.Descripcion
        });
    }
}
