﻿using TrainingZone.Application.Common.Behaviours;
using FluentValidation;
using Mapster;
using MapsterMapper;
using MediatR;
using MediatR.NotificationPublishers;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace TrainingZone.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        var assembly = typeof(DependencyInjection).Assembly;
        // Adding Mediator config
        services.AddMediatR(config =>
        {
            config.RegisterServicesFromAssembly(assembly);
            config.NotificationPublisher = new TaskWhenAllPublisher();
        });
        // Adding FluentValidation config
        services.AddValidatorsFromAssembly(assembly);
        // Adding Mediator Pipeline Behavior services
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(UnhandledExceptionBehaviour<,>));
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        // Adding Mapster config
        services.AddSingleton(GetConfiguredMappingConfig(assembly));
        services.AddScoped<IMapper, ServiceMapper>();
        services.AddHttpContextAccessor();

        return services;
    }

    /// <summary>
    /// Mapster(Mapper) global configuration settings
    /// To learn more about Mapster,
    /// see https://github.com/MapsterMapper/Mapster
    /// </summary>
    /// <returns></returns>
    private static TypeAdapterConfig GetConfiguredMappingConfig(Assembly assembly)
    {
        var config = TypeAdapterConfig.GlobalSettings;

        IList<IRegister> registers = config.Scan(assembly);

        config.Apply(registers);

        return config;
    }
}
