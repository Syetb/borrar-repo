﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Membresias.Queries.GetByIdMembresiaQuery;

public class GetByIdMembresiaQuery : IRequestWrapper<MembresiaDto>
{
    public long Id { get; set; } = default!;
}

public class GetByIdMembresiaQueryHandler : IRequestHandlerWrapper<GetByIdMembresiaQuery, MembresiaDto>
{
    private readonly IMembresiaRepository _membresiaRepository;

    public GetByIdMembresiaQueryHandler(IMembresiaRepository membresiaRepository)
    {
        _membresiaRepository = membresiaRepository;
    }

    public async Task<ApiResponse<MembresiaDto>> Handle(GetByIdMembresiaQuery request, CancellationToken token)
    {
        var membresia = await _membresiaRepository.GetByIdAsync(request.Id, token);
        // Verifica si la categoría existe
        if (membresia == null)
        {
            return new ApiResponse<MembresiaDto>
            {
                Data = null
            };
        }

        return ApiResponse.Success(new MembresiaDto
        {
            Id = membresia.Id,
            Tipo = membresia.Tipo,
            FechaInicio = membresia.FechaInicio,
            FechaFin = membresia.FechaFin,
            Estado = membresia.Estado,
            AppUsuarioID = membresia.AppUsuarioID
        });
    }
}
