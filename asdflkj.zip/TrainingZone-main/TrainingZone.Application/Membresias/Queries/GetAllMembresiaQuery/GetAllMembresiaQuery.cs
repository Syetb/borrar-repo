﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Membresias.Queries.GetAllMembresiaQuery;

public class GetAllMembresiaQuery : IRequestWrapper<List<MembresiaDto>>
{
}

public class GetAllMembresiaQueryHandler : IRequestHandlerWrapper<GetAllMembresiaQuery, List<MembresiaDto>>
{
    private readonly IMembresiaRepository _membresiaRepository;

    public GetAllMembresiaQueryHandler(IMembresiaRepository membresiaRepository)
    {
        _membresiaRepository = membresiaRepository;
    }

    public async Task<ApiResponse<List<MembresiaDto>>> Handle(GetAllMembresiaQuery request, CancellationToken token)
    {
        var membresias = await _membresiaRepository.GetAllAsync(token);
        var membresiasDto = new List<MembresiaDto>();

        foreach (var membresia in membresias)
        {
            var membresiaDto = new MembresiaDto
            {
                Id = membresia.Id,
                Tipo = membresia.Tipo,
                FechaInicio = membresia.FechaInicio,
                FechaFin = membresia.FechaFin,
                Estado = membresia.Estado,
                AppUsuarioID = membresia.AppUsuarioID
            };

            membresiasDto.Add(membresiaDto);
        }

        return new ApiResponse<List<MembresiaDto>>
        {
            Data = membresiasDto
        };
    }
}
