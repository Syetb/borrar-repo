﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Membresias.Commands.CreateMembresiaCommand;

public class CreateMembresiaCommand : IRequestWrapper<MembresiaDto>
{
    public string Tipo { get; set; } = default!;
    public DateTime FechaInicio { get; set; }
    public DateTime FechaFin { get; set; }
    public string Estado { get; set; } = default!;
    public string AppUsuarioID { get; set; } = default!;
}

public class CreateMembresiaCommandHandler : IRequestHandlerWrapper<CreateMembresiaCommand, MembresiaDto>
{
    private readonly IMembresiaRepository _membresiaRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateMembresiaCommandHandler(IMembresiaRepository membresiaRepository, IUnitOfWork unitOfWork)
    {
        _membresiaRepository = membresiaRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<MembresiaDto>> Handle(CreateMembresiaCommand request, CancellationToken token)
    {
        var membresia = new Membresia
        {
            Tipo = request.Tipo,
            FechaInicio = request.FechaInicio,
            FechaFin = request.FechaFin,
            Estado = request.Estado,
            AppUsuarioID = request.AppUsuarioID,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
        };

        _membresiaRepository.Add(membresia);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<MembresiaDto>(new MembresiaDto
        {
            Id = membresia.Id,
            Tipo = membresia.Tipo,
            FechaInicio = membresia.FechaInicio,
            FechaFin = membresia.FechaFin,
            Estado = membresia.Estado,
            AppUsuarioID = membresia.AppUsuarioID
        });
    }
}
