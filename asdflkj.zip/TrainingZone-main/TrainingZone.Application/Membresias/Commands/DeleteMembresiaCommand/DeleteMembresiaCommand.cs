﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Membresias.Commands.DeleteMembresiaCommand;

public class DeleteMembresiaCommand : IRequestWrapper<CategoriaDto>
{
    public long Id { get; set; }
}

public class DeleteMembresiaCommandHandler : IRequestHandlerWrapper<DeleteMembresiaCommand, CategoriaDto>
{
    private readonly IMembresiaRepository _membresiaRepository;
    private readonly IUnitOfWork _unitOfWork;

    public DeleteMembresiaCommandHandler(IMembresiaRepository membresiaRepository, IUnitOfWork unitOfWork)
    {
        _membresiaRepository = membresiaRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<CategoriaDto>> Handle(DeleteMembresiaCommand request, CancellationToken token)
    {
        var membresia = await _membresiaRepository.GetByIdAsync(request.Id, token);
        if (membresia == null)
        {
            return new ApiResponse<CategoriaDto>(new CategoriaDto());
        }

        _membresiaRepository.Remove(membresia);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<CategoriaDto>(new CategoriaDto
        {
            Id = membresia.Id
        });
    }
}
