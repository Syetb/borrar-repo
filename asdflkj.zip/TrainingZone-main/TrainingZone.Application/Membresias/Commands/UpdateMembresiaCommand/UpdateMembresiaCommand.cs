﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Membresias.Commands.UpdateMembresiaCommand;

public class UpdateMembresiaCommand : IRequestWrapper<MembresiaDto>
{
    public long Id { get; set; }
    public string Tipo { get; set; } = default!;
    public DateTime FechaInicio { get; set; }
    public DateTime FechaFin { get; set; }
    public string Estado { get; set; } = default!;
    public string AppUsuarioID { get; set; } = default!;
}

public class UpdateMembresiaCommandHandler : IRequestHandlerWrapper<UpdateMembresiaCommand, MembresiaDto>
{
    private readonly IMembresiaRepository _membresiaRepository;
    private readonly IUnitOfWork _unitOfWork;

    public UpdateMembresiaCommandHandler(IMembresiaRepository membresiaRepository, IUnitOfWork unitOfWork)
    {
        _membresiaRepository = membresiaRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<MembresiaDto>> Handle(UpdateMembresiaCommand request, CancellationToken token)
    {
        var membresia = await _membresiaRepository.GetByIdAsync(request.Id, token);
        if (membresia == null)
        {
            return new ApiResponse<MembresiaDto>(new MembresiaDto());
        }

        var membresiaUpd = new Membresia
        {
            Id = request.Id,
            Tipo = request.Tipo,
            FechaInicio = request.FechaInicio,
            FechaFin = request.FechaFin,
            Estado = request.Estado,
            AppUsuarioID = request.AppUsuarioID,
            UpdatedAt = DateTime.UtcNow
        };

        _membresiaRepository.Update(membresiaUpd);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<MembresiaDto>(new MembresiaDto
        {
            Id = membresiaUpd.Id,
            Tipo = membresiaUpd.Tipo,
            FechaInicio = membresiaUpd.FechaInicio,
            FechaFin = membresiaUpd.FechaFin,
            Estado = membresiaUpd.Estado,
            AppUsuarioID = membresiaUpd.AppUsuarioID
        });
    }
}
