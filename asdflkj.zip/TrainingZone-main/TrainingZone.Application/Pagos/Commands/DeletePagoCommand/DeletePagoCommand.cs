﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pagos.Commands.DeletePagoCommand;

public class DeletePagoCommand : IRequestWrapper<PagoDto>
{
    public long Id { get; set; }
}

public class DeletePagoCommandHandler : IRequestHandlerWrapper<DeletePagoCommand, PagoDto>
{
    private readonly IPagoRepository _pagoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public DeletePagoCommandHandler(IPagoRepository pagoRepository, IUnitOfWork unitOfWork)
    {
        _pagoRepository = pagoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<PagoDto>> Handle(DeletePagoCommand request, CancellationToken token)
    {
        var pago = await _pagoRepository.GetByIdAsync(request.Id, token);
        if (pago == null)
        {
            return new ApiResponse<PagoDto>(new PagoDto());
        }

        _pagoRepository.Remove(pago);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<PagoDto>(new PagoDto
        {
            Id = pago.Id
        });
    }
}
