﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pagos.Commands.CreatePagoCommand;

public class CreatePagoCommand : IRequestWrapper<PagoDto>
{
    public string EstadoPago { get; set; } = default!;
    public DateTime FechaPago { get; set; }
    public double Precio { get; set; }
    public long MembresiaID { get; set; }
}

public class CreatePagoCommandHandler : IRequestHandlerWrapper<CreatePagoCommand, PagoDto>
{
    private readonly IPagoRepository _pagoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreatePagoCommandHandler(IPagoRepository pagoRepository, IUnitOfWork unitOfWork)
    {
        _pagoRepository = pagoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<PagoDto>> Handle(CreatePagoCommand request, CancellationToken token)
    {
        var pago = new Pago
        {
            EstadoPago = request.EstadoPago,
            FechaPago = request.FechaPago,
            Precio = request.Precio,
            MembresiaID = request.MembresiaID,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
        };

        _pagoRepository.Add(pago);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<PagoDto>(new PagoDto
        {
            Id = pago.Id,
            EstadoPago = pago.EstadoPago,
            FechaPago = pago.FechaPago,
            Precio = pago.Precio,
            MembresiaID = pago.MembresiaID,
        });
    }
}
