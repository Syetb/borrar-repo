﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pagos.Commands.UpdatePagoCommand;

public class UpdatePagoCommand : IRequestWrapper<PagoDto>
{
    public long Id { get; set; }
    public string EstadoPago { get; set; } = default!;
    public DateTime FechaPago { get; set; }
    public double Precio { get; set; }
    public long MembresiaID { get; set; }
}

public class CreateCategoriaCommandHandler : IRequestHandlerWrapper<UpdatePagoCommand, PagoDto>
{
    private readonly IPagoRepository _pagoRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateCategoriaCommandHandler(IPagoRepository pagoRepository, IUnitOfWork unitOfWork)
    {
        _pagoRepository = pagoRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<ApiResponse<PagoDto>> Handle(UpdatePagoCommand request, CancellationToken token)
    {
        var pago = await _pagoRepository.GetByIdAsync(request.Id, token);
        if (pago == null)
        {
            return new ApiResponse<PagoDto>(new PagoDto());
        }

        var pagoUpd = new Pago
        {
            EstadoPago = request.EstadoPago,
            FechaPago = request.FechaPago,
            Precio = request.Precio,
            MembresiaID = request.MembresiaID,
            UpdatedAt = DateTime.UtcNow,
        };

        _pagoRepository.Update(pagoUpd);
        await _unitOfWork.SaveChangesAsync(token);

        return new ApiResponse<PagoDto>(new PagoDto
        {
            Id = pago.Id,
            EstadoPago = pago.EstadoPago,
            FechaPago = pago.FechaPago,
            Precio = pago.Precio,
            MembresiaID = pago.MembresiaID,
        });
    }
}
