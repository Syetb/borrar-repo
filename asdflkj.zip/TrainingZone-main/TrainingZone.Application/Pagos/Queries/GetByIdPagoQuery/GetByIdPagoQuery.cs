﻿
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pagos.Queries.GetByIdPagoQuery;

public class GetByIdPagoQuery : IRequestWrapper<PagoDto>
{
    public long Id { get; set; } = default!;
}

public class GetByIdPagoQueryHandler : IRequestHandlerWrapper<GetByIdPagoQuery, PagoDto>
{
    private readonly IPagoRepository _pagoRepository;

    public GetByIdPagoQueryHandler(IPagoRepository pagoRepository)
    {
        _pagoRepository = pagoRepository;
    }

    public async Task<ApiResponse<PagoDto>> Handle(GetByIdPagoQuery request, CancellationToken token)
    {
        var pago = await _pagoRepository.GetByIdAsync(request.Id, token);
        // Verifica si la categoría existe
        if (pago == null)
        {
            return new ApiResponse<PagoDto>
            {
                Data = null
            };
        }

        return ApiResponse.Success(new PagoDto
        {
            Id = pago.Id,
            EstadoPago = pago.EstadoPago,
            FechaPago = pago.FechaPago,
            Precio = pago.Precio,
            MembresiaID = pago.MembresiaID,
        });
    }
}
