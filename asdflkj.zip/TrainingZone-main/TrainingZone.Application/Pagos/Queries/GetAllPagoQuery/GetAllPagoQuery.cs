﻿using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Pagos.Queries.GetAllPagoQuery;

public class GetAllPagoQuery : IRequestWrapper<List<PagoDto>>
{
}

public class GetAllPagoQueryHandler : IRequestHandlerWrapper<GetAllPagoQuery, List<PagoDto>>
{
    private readonly IPagoRepository _pagoRepository;

    public GetAllPagoQueryHandler(IPagoRepository pagoRepository)
    {
        _pagoRepository = pagoRepository;
    }

    public async Task<ApiResponse<List<PagoDto>>> Handle(GetAllPagoQuery request, CancellationToken token)
    {
        var pagos = await _pagoRepository.GetAllAsync(token);
        var pagosDto = new List<PagoDto>();

        foreach (var pago in pagos)
        {
            var pagoDto = new PagoDto
            {
                Id = pago.Id,
                EstadoPago = pago.EstadoPago,
                FechaPago = pago.FechaPago,
                Precio = pago.Precio,
                MembresiaID = pago.MembresiaID,
            };

            pagosDto.Add(pagoDto);
        }

        return new ApiResponse<List<PagoDto>>
        {
            Data = pagosDto
        };
    }
}
