﻿using Microsoft.AspNetCore.Identity;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Users.Commands.CreateUserCommand
{
    public class CreateUserCommand : IRequestWrapper<string>
    {
        public string Email { get; set; } = default!;
        public string Password { get; set; } = default!;
        public string Role { get; set; } = default!;
        public string Nombre { get; set; } = default!;
        public string Apellido { get; set; } = default!;
        public string Telefono { get; set; } = default!;
        public float Peso { get; set; }
        public string Genero { get; set; } = default!;
        public string? Image { get; set; } = default!;
    }

    public class CreateUserCommandHandler : IRequestHandlerWrapper<CreateUserCommand, string>
    {
        private readonly UserManager<AppUsuario> _userManager;
        private readonly IPesoRepository _pesoRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateUserCommandHandler(UserManager<AppUsuario> userManager, IPesoRepository pesoRepository, IUnitOfWork unitOfWork)
        {
            _userManager = userManager;
            _pesoRepository = pesoRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<ApiResponse<string>> Handle(CreateUserCommand request, CancellationToken token)
        {
            var user = new AppUsuario
            {
                UserName = request.Email,
                Email = request.Email,
                Nombre = request.Nombre,
                Apellido = request.Apellido,
                PhoneNumber = request.Telefono,
                Genero = request.Genero,
                Image = request.Image,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
            };

            var result = await _userManager.CreateAsync(user, request.Password);

            if (!result.Succeeded)
            {
                return ApiResponse.Failed($"ERROR ${result.Errors}");
            }

            var resultRole = await _userManager.AddToRoleAsync(user, request.Role);
            if (!resultRole.Succeeded)
            {
                return ApiResponse.Failed($"ERROR ${resultRole.Errors}");
            }

            var peso = new Peso
            {
                PesoActual = request.Peso,
                FechaRegistro = DateTime.UtcNow,
                AppUsuarioID = user.Id
            };

            _pesoRepository.Add(peso);
            await _unitOfWork.SaveChangesAsync(token);

            return ApiResponse.Success("Registration successful");
        }
    }
}
