﻿using Microsoft.AspNetCore.Identity;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Entities;

namespace TrainingZone.Application.Users.Commands.DeleteUserCommand;

public class DeleteUserCommand : IRequestWrapper<string>
{
    public string UserId { get; set; } = default!;
}

public class DeleteUserCommandHandler : IRequestHandlerWrapper<DeleteUserCommand, string>
{
    private readonly UserManager<AppUsuario> _userManager;

    public DeleteUserCommandHandler(UserManager<AppUsuario> userManager)
    {
        _userManager = userManager;
    }

    public async Task<ApiResponse<string>> Handle(DeleteUserCommand request, CancellationToken token)
    {
        // Buscar al usuario por su ID
        var user = await _userManager.FindByIdAsync(request.UserId);

        if (user != null)
        {
            // Si el usuario existe, procedemos a eliminarlo
            var result = await _userManager.DeleteAsync(user);

            if (!result.Succeeded)
            {
                return ApiResponse.Failed($"ERROR ${result.Errors}");
            }

            return ApiResponse.Success("Delete successful");
        }
        else
        {
            return ApiResponse.Failed($"ERROR NOFOUND");
        }
    }
}
