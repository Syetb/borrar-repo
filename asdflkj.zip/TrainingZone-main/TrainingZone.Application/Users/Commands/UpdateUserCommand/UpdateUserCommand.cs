﻿using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json.Linq;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Connections;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Users.Commands.UpdateUserCommand
{
    public class UpdateUserCommand : IRequestWrapper<string>
    {
        public string UserId { get; set; } = default!;
        public string Email { get; set; } = default!;
        public string Password { get; set; } = default!;
        public string Role { get; set; } = default!;
        public string Nombre { get; set; } = default!;
        public string Apellido { get; set; } = default!;
        public float Peso { get; set; }
        public string Genero { get; set; } = default!;
        public string? Image { get; set; } = default!;
    }

    public class UpdateUserCommandHandler : IRequestHandlerWrapper<UpdateUserCommand, string>
    {
        private readonly UserManager<AppUsuario> _userManager;
        private readonly IPesoRepository _pesoRepository;
        private readonly IUnitOfWork _unitOfWork;

        public UpdateUserCommandHandler(UserManager<AppUsuario> userManager, IPesoRepository pesoRepository, IUnitOfWork unitOfWork)
        {
            _userManager = userManager;
            _pesoRepository = pesoRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<ApiResponse<string>> Handle(UpdateUserCommand request, CancellationToken token)
        {
            var user = await _userManager.FindByIdAsync(request.UserId);
            if (user == null)
            {
                return ApiResponse.Failed($"User with ID {request.UserId} not found.");
            }
            var newUser = new AppUsuario
            {
                UserName = request.Email,
                Email = request.Email,
                Nombre = request.Nombre,
                Apellido = request.Apellido,
                Genero = request.Genero,
                Image = request.Image,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
            };

            var result = await _userManager.UpdateAsync(newUser);

            if (!result.Succeeded)
            {
                return ApiResponse.Failed($"ERROR ${result.Errors}");
            }

            var resultRole = await _userManager.AddToRoleAsync(user, request.Role);
            if (!resultRole.Succeeded)
            {
                return ApiResponse.Failed($"ERROR ${resultRole.Errors}");
            }

            var peso = new Peso
            {
                PesoActual = request.Peso,
                FechaRegistro = DateTime.UtcNow,
                AppUsuarioID = user.Id
            };

            _pesoRepository.Add(peso);
            await _unitOfWork.SaveChangesAsync(token);

            return ApiResponse.Success("Registration successful");
        }
    }
}
