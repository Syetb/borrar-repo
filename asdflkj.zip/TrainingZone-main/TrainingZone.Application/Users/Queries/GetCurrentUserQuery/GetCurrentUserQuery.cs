﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Users.Queries.GetCurrentUserQuery;

public class GetCurrentUserQuery : IRequestWrapper<UsuarioDto>
{
    public string UserId { get; set; } = string.Empty;
}

public class GetCurrentUserQueryHandler : IRequestHandlerWrapper<GetCurrentUserQuery, UsuarioDto>
{
    private readonly UserManager<AppUsuario> _userManager;
    private readonly IAppUsuarioRepository _appUserRepository;

    public GetCurrentUserQueryHandler(UserManager<AppUsuario> userManager, IAppUsuarioRepository appUserRepository)
    {
        _userManager = userManager;
        _appUserRepository = appUserRepository;
    }

    public async Task<ApiResponse<UsuarioDto>> Handle(GetCurrentUserQuery request, CancellationToken token)
    {
        var user = await _appUserRepository
            .GetByIdAsync(request.UserId, cancellationToken: token);

        if (user == null)
        {
            return ApiResponse.Failed(new UsuarioDto { Id = "", Email = "" });
        }

        IList<string> userRoles = await _userManager.GetRolesAsync(user);
        var membresias = user.Membresias;

        if (userRoles[0] == "ADMINISTRADOR")
        {
            return ApiResponse.Success(new UsuarioDto
            {
                Id = user.Id,
                Email = user.Email!,
                Nombre = user.Nombre!,
                Apellido = user.Apellido!,
                Telefono = user.PhoneNumber!,
                Peso = 0.0f,
                Genero = user.Genero!,
                Image = user.Image!,
                Roles = userRoles,
                Membresia = "No Aplica",

            });
        }
        else
        {
            return ApiResponse.Success(new UsuarioDto
            {
                Id = user.Id,
                Email = user.Email!,
                Nombre = user.Nombre!,
                Apellido = user.Apellido!,
                Telefono = user.PhoneNumber!,
                Peso = user.Pesos.Count > 0 ? user.Pesos.Last().PesoActual! : 0.0f,
                Genero = user.Genero!,
                Image = user.Image!,
                Roles = userRoles,
                Membresia = membresias.Count == 0 ? "No Registrada" : membresias.Last().Tipo,

            });
        }
    }
}
