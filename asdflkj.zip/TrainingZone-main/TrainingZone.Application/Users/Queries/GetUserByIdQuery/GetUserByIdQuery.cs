﻿using Microsoft.AspNetCore.Identity;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Users.Queries.GetUserByIdQuery;

public class GetUserByIdQuery : IRequestWrapper<UsuarioDto>
{
    public string UserId { get; set; } = default!;
}

public class GetUserByIdQueryHandler : IRequestHandlerWrapper<GetUserByIdQuery, UsuarioDto>
{
    private readonly UserManager<AppUsuario> _userManager;
    private readonly IAppUsuarioRepository _appUserRepository;

    public GetUserByIdQueryHandler(UserManager<AppUsuario> userManager, IAppUsuarioRepository appUserRepository)
    {
        _userManager = userManager;
        _appUserRepository = appUserRepository;
    }

    public async Task<ApiResponse<UsuarioDto>> Handle(GetUserByIdQuery request, CancellationToken token)
    {
        var user = await _appUserRepository
            .GetByIdAsync(request.UserId, cancellationToken: token);
                
        if (user == null)
        {
            return ApiResponse.Failed(new UsuarioDto { Id = "", Email = "" });
        }

        IList<string> userRoles = await _userManager.GetRolesAsync(user);
        var membresias = user.Membresias;

        return ApiResponse.Success(new UsuarioDto
        {
            Id = user.Id,
            Email = user.Email!,
            Nombre = user.Nombre!,
            Apellido = user.Apellido!,
            Telefono = user.PhoneNumber!,
            Peso = user.Pesos.Count > 0 ? user.Pesos.Last().PesoActual! : 0.0f,
            Genero = user.Genero!,
            Image = user.Image!,
            Roles = userRoles,
            Membresia = membresias.Count == 0 ? "No Registrada" : membresias.Last().Tipo
        });
    }
}
