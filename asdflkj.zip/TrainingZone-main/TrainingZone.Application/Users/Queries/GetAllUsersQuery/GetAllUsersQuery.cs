﻿using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json.Linq;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Interfaces;
using TrainingZone.Domain.Dto;
using TrainingZone.Domain.Entities;
using TrainingZone.Domain.Interfaces.Repositories;

namespace TrainingZone.Application.Users.Queries.GetAllUsersQuery
{
    public class GetAllUsersQuery : IRequestWrapper<List<UsuarioDto>>
    {
        public string Filtro { get; set; } = default!;
    }

    public class GetAllUsersQueryHandler : IRequestHandlerWrapper<GetAllUsersQuery, List<UsuarioDto>>
    {
        private readonly UserManager<AppUsuario> _userManager;
        private readonly IAppUsuarioRepository _appUserRepository;

        public GetAllUsersQueryHandler(UserManager<AppUsuario> userManager, IAppUsuarioRepository appUserRepository)
        {
            _userManager = userManager;
            _appUserRepository = appUserRepository;
        }

        public async Task<ApiResponse<List<UsuarioDto>>> Handle(GetAllUsersQuery request, CancellationToken token)
        {
            var users = await _appUserRepository
            .GetAllAsync(cancellationToken: token);

            if (users.Count == 0)
            {
                return ApiResponse.Failed(new List<UsuarioDto>());
            }

            var userDtos = new List<UsuarioDto>();

            foreach (var user in users)
            {
                var userRoles = await _userManager.GetRolesAsync(user);
                var membresias = user.Membresias;

                if (request.Filtro == "TODOS" )
                {
                    var userDto = new UsuarioDto
                    {
                        Id = user.Id,
                        Email = user.Email!,
                        Nombre = user.Nombre!,
                        Apellido = user.Apellido!,
                        Telefono = user.PhoneNumber!,
                        Peso = user.Pesos.Count > 0 ? user.Pesos.Last().PesoActual! : 0.0f,
                        Genero = user.Genero!,
                        Image = user.Image!,
                        Roles = userRoles,
                        Membresia = membresias.Count == 0 ? "No Registrada" : membresias.Last().Tipo,
                    };

                    userDtos.Add(userDto);
                }
                else
                {
                    if(userRoles.Contains(request.Filtro))
                    {
                        var userDto = new UsuarioDto
                        {
                            Id = user.Id,
                            Email = user.Email!,
                            Nombre = user.Nombre!,
                            Apellido = user.Apellido!,
                            Telefono = user.PhoneNumber!,
                            Peso = user.Pesos.Count > 0 ? user.Pesos.Last().PesoActual! : 0.0f,
                            Genero = user.Genero!,
                            Image = user.Image!,
                            Roles = userRoles,
                            Membresia = membresias.Count == 0 ? "No Registrada" : membresias.Last().Tipo,
                        };

                        userDtos.Add(userDto);
                    }
                }
            }

            return new ApiResponse<List<UsuarioDto>>
            {
                Data = userDtos,
            };
        }
    }
}
