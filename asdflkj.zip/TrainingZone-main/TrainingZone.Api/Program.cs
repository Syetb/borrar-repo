using Microsoft.OpenApi.Models;
using Serilog;
using System.Text.Json.Serialization;
using TrainingZone.Application;
using TrainingZone.Application.Common.Serializers;
using TrainingZone.Infrastructure;
using TrainingZone.Api.Filters;
using TrainingZone.Infrastructure.Extensions;
using TrainingZone.Domain.Entities;
using TrainingZone.Infrastructure.Overrides;

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .CreateBootstrapLogger();

try
{
    Log.Information("Starting web api");

    var builder = WebApplication.CreateBuilder(args);

    // Add services to the container.
    builder.Services.AddApplication();
    builder.Services.AddInfrastructure(builder.Configuration);
    builder.Host.UseSerilog((context, configuration) =>
        configuration.ReadFrom.Configuration(context.Configuration)
    );
    // Enable CORS
    builder.Services.AddCors(options =>
    {
        options.AddPolicy("AllowAnyHost",
            builder =>
            {
                builder
                    .AllowAnyOrigin() // Allow requests from any origin
                    .AllowAnyMethod() // Allow any HTTP method
                    .AllowAnyHeader(); // Allow any header
            });
    });
    builder.Services.AddControllers(opt => opt.Filters.Add<ApiExceptionFilterAttribute>())
        .ConfigureApiBehaviorOptions(opt => { opt.SuppressModelStateInvalidFilter = true; })
        .AddJsonOptions(opt =>
        {
            opt.JsonSerializerOptions.PropertyNamingPolicy = new SnakeCaseNamingPolicy();
            opt.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        });
    // Setup routing controller name to lower case 
    builder.Services.Configure<RouteOptions>(options => options.LowercaseUrls = true);

    // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "Training Zone API", Version = "1.0.0" });
        c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.ApiKey,
            Name = "Authorization",
            In = ParameterLocation.Header,
            Description = "Type into the textbox: Bearer {your JWT token}.",
            Scheme = "Bearer"
        });
        c.AddSecurityRequirement(new OpenApiSecurityRequirement()
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                        {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                        },
                        Scheme = "oauth2",
                        Name = "Bearer",
                        In = ParameterLocation.Header,
                },
                new List<string>()
            }
        });
    });

    builder.Services.AddHsts(options =>
    {
        options.Preload = true;
        options.IncludeSubDomains = true;
        options.MaxAge = TimeSpan.FromDays(30);
    });

    //builder.Services.AddScoped(typeof(IDapperRepository), typeof(DapperRepository));
    //builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

    var app = builder.Build();

    // Configure the HTTP request pipeline.
    if (!app.Environment.IsDevelopment())
    {
        app.UseExceptionHandler("/Error");
        // The default HSTS value is 30 days. See https://aka.ms/aspnetcore-hsts.
        app.UseHsts();
        app.UseSwagger();
        app.UseSwaggerUI(c => c.DocumentTitle = "Training Zone API");

        app.UseHttpsRedirection();
    }
    else
    {
        app.UseSwagger();
        app.UseSwaggerUI(c => c.DocumentTitle = "Training Zone API");

        app.ApplyMigrations();
    }

    // Use CORS
    app.UseCors("AllowAnyHost");

    app.UseSerilogRequestLogging();

    

    app.MapGroup("/api").MapIdentityApiFilterable<AppUsuario>(new IdentityApiEndpointRouteBuilderOptions()
    {
        ExcludeRegisterPost = true,
        ExcludeLoginPost = false,
        ExcludeRefreshPost = false,
        ExcludeConfirmEmailGet = true,
        ExcludeResendConfirmationEmailPost = true,
        ExcludeForgotPasswordPost = true,
        ExcludeResetPasswordPost = true,
        ExcludeManageGroup = true,
        Exclude2faPost = true,
        ExcludegInfoGet = true,
        ExcludeInfoPost = true,
    }).WithTags("Authorization");

    app.MapControllers();

    app.Run();
}
catch (Exception ex)
{

    Log.Fatal(ex, "Application terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}
