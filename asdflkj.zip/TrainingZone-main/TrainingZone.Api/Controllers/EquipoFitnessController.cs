﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.EquipoFitnesses.Commands.CreateEquipoFitness;
using TrainingZone.Application.EquipoFitnesses.Commands.DeleteEquipoFitness;
using TrainingZone.Application.EquipoFitnesses.Commands.UpdateEquipoFitness;
using TrainingZone.Application.EquipoFitnesses.Queries.GetAllEquipoFitness;
using TrainingZone.Application.EquipoFitnesses.Queries.GetByIdEquipoFitness;

namespace TrainingZone.Api.Controllers;

[Route("api/equipo_fitness")]
public class EquipoFitnessController : BaseApiController
{
    /// <summary>
    /// Alta de equipos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [Authorize(Roles = "ADMIN,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> CreateEquipoFitness([FromBody] CreateEquipoFitnessCommand command)
    {
        var credentials = await Mediator.Send(command);
        return Ok(credentials);
    }

    /// <summary>
    /// Actualiza equipos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{id}")]
    [Authorize(Roles = "ADMIN,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateEquipoFitness(UpdateEquipoFitnessCommand command, long Id)
    {
        return Ok(await Mediator.Send(command.Id = Id));
    }

    /// <summary>
    /// Elimina equipos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{Id}")]
    [Authorize(Roles = "ADMIN,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteEquipoFitness([FromRoute] long Id)
    {
        var command = new DeleteEquipoFitnessCommand { Id = Id };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene equipos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR,CLIENTE")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllEquipoFitness()
    {
        var query = new GetAllEquipoFitnessQuery();
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene equipos por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{id}")]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR,CLIENTE")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetEquipoFitnessById(long Id)
    {
        var query = new GetByIdEquipoFitnessQuery { Id = Id };
        return Ok(await Mediator.Send(query));
    }
}
