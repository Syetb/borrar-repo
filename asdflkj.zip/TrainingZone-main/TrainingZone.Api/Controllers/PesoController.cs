﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Claims;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Pesos.Commands.CreatePesoCommand;
using TrainingZone.Application.Pesos.Queries.GetAllPesosByUsuarioQuery;
using TrainingZone.Application.Users.Commands.DeleteUserCommand;
using TrainingZone.Application.Users.Commands.UpdateUserCommand;

namespace TrainingZone.Api.Controllers
{
    public class PesoController : BaseApiController
    {
        /// <summary>
        /// Alta de peso
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPost()]
        
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<ActionResult<ApiResponse<string>>> AddPesos([FromBody] CreatePesoCommand command)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }
            command.UserId = userId;

            return Ok(await Mediator.Send(command));
        }

        /// <summary>
        /// Actualiza Peso
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<ActionResult<ApiResponse<string>>> UpdatePeso(UpdateUserCommand command, string id)
        {
            return Ok(await Mediator.Send(command.UserId = id));
        }

        /// <summary>
        /// Elimina pesos
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [HttpDelete("{Id}")]
        [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<ActionResult<ApiResponse<string>>> DeletePeso([FromRoute] string Id)
        {
            var command = new DeleteUserCommand { UserId = Id };
            return Ok(await Mediator.Send(command));
        }

        /// <summary>
        /// Obtiene todos los pesos por Usuario ID
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [HttpGet()]
        [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR,CLIENTE")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<ActionResult<ApiResponse<string>>> GetAllPesosByUsuario([FromQuery] GetAllPesosByUsuarioQuery query)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }

            query.UserId = userId;

            return Ok(await Mediator.Send(query));
        }
    }
}
