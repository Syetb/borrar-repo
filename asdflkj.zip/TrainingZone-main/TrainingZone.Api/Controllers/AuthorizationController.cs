﻿using TrainingZone.Application.Common.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.Securities.Commands.DeleteTokenCommand;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace TrainingZone.Api.Controllers;

[Route("api")]
public class AuthorizationController : BaseApiController
{
    /// <summary>
    /// Logout user session
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost("logout")]
    [Authorize]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> SessionLogout()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userId == null)
        {
            return Unauthorized();
        }

        return Ok(await Mediator.Send(new DeleteTokenCommand()));
    }
}
