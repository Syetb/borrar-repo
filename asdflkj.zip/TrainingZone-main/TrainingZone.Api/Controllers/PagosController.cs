﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Pagos.Commands.CreatePagoCommand;
using TrainingZone.Application.Pagos.Commands.DeletePagoCommand;
using TrainingZone.Application.Pagos.Commands.UpdatePagoCommand;
using TrainingZone.Application.Pagos.Queries.GetAllPagoQuery;
using TrainingZone.Application.Pagos.Queries.GetByIdPagoQuery;

namespace TrainingZone.Api.Controllers;

public class PagosController : BaseApiController
{
    /// <summary>
    /// Crea Pagos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> CreateRoles([FromBody] CreatePagoCommand command)
    {
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Actualiza Pagos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateRoles(UpdatePagoCommand command, long Id)
    {
        return Ok(await Mediator.Send(command.Id = Id));
    }

    /// <summary>
    /// Elimina Pagos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteRoles([FromRoute] long Id)
    {
        var command = new DeletePagoCommand { Id = Id };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene Pagos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllRoles()
    {
        var query = new GetAllPagoQuery();
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene Pago por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetRoleById(long Id)
    {
        var query = new GetByIdPagoQuery { Id = Id };
        return Ok(await Mediator.Send(query));
    }
}
