﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.ArVideos.Command.CreateArVideoCommand;
using TrainingZone.Application.ArVideos.Command.DeleteArVideoCommand;
using TrainingZone.Application.ArVideos.Command.UpdateArVideoCommand;
using TrainingZone.Application.ArVideos.Queries.GetAllArVideoQuery;
using TrainingZone.Application.ArVideos.Queries.GetByIdArVideoQuery;
using TrainingZone.Application.Common.Models;

namespace TrainingZone.Api.Controllers;

public class ArVideosController : BaseApiController
{
    /// <summary>
    /// Crea AR Videos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> CreateRoles([FromBody] CreateArVideoCommand command)
    {
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Actualiza AR Videos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateRoles(UpdateArVideoCommand command, long Id)
    {
        return Ok(await Mediator.Send(command.Id = Id));
    }

    /// <summary>
    /// Elimina AR Videos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteRoles([FromRoute] long Id)
    {
        var command = new DeleteArVideoCommand { Id = Id };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene AR Videos
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllRoles()
    {
        var query = new GetAllArVideoQuery();
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene AR Videos por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetRoleById(long Id)
    {
        var query = new GetByIdArVideoQuery { Id = Id };
        return Ok(await Mediator.Send(query));
    }
}
