﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.Categorias.Commands.CreateCategoriaCommand;
using TrainingZone.Application.Categorias.Commands.DeleteCategoriaCommand;
using TrainingZone.Application.Categorias.Commands.UpdateCategoriaCommand;
using TrainingZone.Application.Categorias.Queries.GetAllCategoriasQuery;
using TrainingZone.Application.Categorias.Queries.GetByIdCategoriaQuery;
using TrainingZone.Application.Common.Models;

namespace TrainingZone.Api.Controllers;

public class CategoriasController : BaseApiController
{
    /// <summary>
    /// Crea Categorias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> CreateCategoria([FromBody] CreateCategoriaCommand command)
    {
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Actualiza Categorias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateCategoria(UpdateCategoriaCommand command, long Id)
    {
        return Ok(await Mediator.Send(command.Id = Id));
    }

    /// <summary>
    /// Elimina Categorias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteCategoria([FromRoute] long Id)
    {
        var command = new DeleteCategoriaCommand { Id = Id };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene Categorias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllCategorias()
    {
        var query = new GetAllCategoriasQuery();
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene Categorias por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetCategoriaById(long Id)
    {
        var query = new GetByIdCategoriasQuery { Id = Id };
        return Ok(await Mediator.Send(query));
    }
}
