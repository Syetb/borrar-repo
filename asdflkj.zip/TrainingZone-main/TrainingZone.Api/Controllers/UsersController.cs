﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Security.Claims;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Users.Commands.CreateUserCommand;
using TrainingZone.Application.Users.Commands.DeleteUserCommand;
using TrainingZone.Application.Users.Commands.UpdateUserCommand;
using TrainingZone.Application.Users.Queries.GetAllUsersQuery;
using TrainingZone.Application.Users.Queries.GetCurrentUserQuery;
using TrainingZone.Application.Users.Queries.GetUserByIdQuery;

namespace TrainingZone.Api.Controllers;

public class UsersController : BaseApiController
{
    /// <summary>
    /// Alta de usuarios
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> RegisterUsers([FromBody] CreateUserCommand command)
    {
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Actualiza usuarios
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{userId}")]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateUsers(UpdateUserCommand command, string userId)
    {
        return Ok(await Mediator.Send(command.UserId = userId));
    }

    /// <summary>
    /// Elimina usuarios
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{userId}")]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteUsers([FromRoute] string userId)
    {
        var command = new DeleteUserCommand { UserId = userId };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene usuario actual
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("me")]
    [Authorize]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetCurrentUser()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userId == null)
        {
            return Unauthorized();
        }

        var query = new GetCurrentUserQuery { UserId = userId };
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene todos los usuarios
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllUsers([FromQuery] string filtro="TODOS")
    {
        var query = new GetAllUsersQuery { Filtro = filtro };
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene usuario por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{userId}")]
    [Authorize(Roles = "ADMINISTRADOR,INSTRUCTOR")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetUserById(string userId)
    {
        var query = new GetUserByIdQuery { UserId = userId };
        return Ok(await Mediator.Send(query));
    }
}
