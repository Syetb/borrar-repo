﻿using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace TrainingZone.Api.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CheckController : BaseApiController
{

    /// <summary>
    /// Get Check Web Api
    /// </summary>
    /// <returns></returns>
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [HttpGet]
    public ActionResult Details()
    {
        return Ok(new { status = "OK" });
    }
}
