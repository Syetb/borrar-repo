﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Membresias.Commands.CreateMembresiaCommand;
using TrainingZone.Application.Membresias.Commands.DeleteMembresiaCommand;
using TrainingZone.Application.Membresias.Commands.UpdateMembresiaCommand;
using TrainingZone.Application.Membresias.Queries.GetAllMembresiaQuery;
using TrainingZone.Application.Membresias.Queries.GetByIdMembresiaQuery;

namespace TrainingZone.Api.Controllers;

public class MembresiasController : BaseApiController
{
    /// <summary>
    /// Crea Membresias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> CreateRoles([FromBody] CreateMembresiaCommand command)
    {
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Actualiza Membresias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateRoles(UpdateMembresiaCommand command, long Id)
    {
        return Ok(await Mediator.Send(command.Id = Id));
    }

    /// <summary>
    /// Elimina Membresias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteRoles([FromRoute] long Id)
    {
        var command = new DeleteMembresiaCommand { Id = Id };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene Membresias
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllRoles()
    {
        var query = new GetAllMembresiaQuery();
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene Membresia por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{Id}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetRoleById(long Id)
    {
        var query = new GetByIdMembresiaQuery { Id = Id };
        return Ok(await Mediator.Send(query));
    }
}
