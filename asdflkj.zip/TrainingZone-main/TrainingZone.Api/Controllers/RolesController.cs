﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using TrainingZone.Application.Common.Models;
using TrainingZone.Application.Roles.Commands.CreateRoleCommand;
using TrainingZone.Application.Roles.Commands.DeleteRoleCommand;
using TrainingZone.Application.Roles.Commands.UpdateRoleCommand;
using TrainingZone.Application.Roles.Queries.GetAllRolesQuery;
using TrainingZone.Application.Roles.Queries.GetRoleByIdQuery;

namespace TrainingZone.Api.Controllers;

public class RolesController : BaseApiController
{
    /// <summary>
    /// Crea de roles
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPost()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> CreateRoles([FromBody] CreateRoleCommand command)
    {
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Actualiza roles
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpPut("{roleId}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> UpdateRoles(UpdateRoleCommand command, string roleId)
    {
        return Ok(await Mediator.Send(command.RoleId = roleId));
    }

    /// <summary>
    /// Elimina roles
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpDelete("{roleId}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> DeleteRoles([FromRoute] string roleId)
    {
        var command = new DeleteRoleCommand { RoleId = roleId };
        return Ok(await Mediator.Send(command));
    }

    /// <summary>
    /// Obtiene roles
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet()]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetAllRoles()
    {
        var query = new GetAllRolesQuery();
        return Ok(await Mediator.Send(query));
    }

    /// <summary>
    /// Obtiene role por ID
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [HttpGet("{roleId}")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    [ProducesResponseType((int)HttpStatusCode.BadRequest)]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    public async Task<ActionResult<ApiResponse<string>>> GetRoleById(string roleId)
    {
        var query = new GetRoleByIdQuery { RoleId = roleId };
        return Ok(await Mediator.Send(query));
    }
}
